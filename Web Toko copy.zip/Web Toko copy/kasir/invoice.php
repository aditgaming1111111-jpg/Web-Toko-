<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/config/bootstrap.php';

$user = require_login(['kasir']);
$transactionId = filter_input(INPUT_GET, 'id', FILTER_VALIDATE_INT);

if (!$transactionId) {
    $lastTransaction = $pdo->prepare(
        'SELECT id_transaksi FROM transaksi WHERE id_user = ? ORDER BY id_transaksi DESC LIMIT 1'
    );
    $lastTransaction->execute([$user['id_user']]);
    $transactionId = (int) $lastTransaction->fetchColumn();
}

if (!$transactionId) {
    flash('warning', 'Belum ada transaksi untuk dicetak.');
    redirect('kasir/transaksi.php');
}

$transactionStatement = $pdo->prepare(
    'SELECT t.*, u.nama AS kasir, p.nama AS pelanggan
     FROM transaksi t
     JOIN users u ON u.id_user = t.id_user
     LEFT JOIN pelanggan p ON p.id_pelanggan = t.id_pelanggan
     WHERE t.id_transaksi = ? AND t.id_user = ?'
);
$transactionStatement->execute([$transactionId, $user['id_user']]);
$transaction = $transactionStatement->fetch();

if (!$transaction) {
    http_response_code(404);
    exit('Invoice tidak ditemukan.');
}

$itemStatement = $pdo->prepare(
    'SELECT d.*, b.kode_barang, b.nama_barang, b.satuan
     FROM detail_transaksi d
     JOIN barang b ON b.id_barang = d.id_barang
     WHERE d.id_transaksi = ?'
);
$itemStatement->execute([$transactionId]);
$items = $itemStatement->fetchAll();
$shouldPrint = isset($_GET['print']);

if ($shouldPrint) {
    audit($pdo, (int) $user['id_user'], 'Mencetak invoice ' . $transaction['no_transaksi']);
}

$pageTitle = 'Invoice ' . $transaction['no_transaksi'];
require dirname(__DIR__) . '/includes/header.php';
?>

<div class="d-flex justify-content-between align-items-center mb-4 no-print">
  <div><h1 class="section-title mb-1">Invoice</h1><p class="text-muted mb-0">Invoice transaksi yang siap dicetak.</p></div>
  <a class="btn btn-primary" href="<?= url('kasir/invoice.php?id=' . $transactionId . '&print=1') ?>"><i class="bi bi-printer me-1"></i> Cetak Invoice</a>
</div>

<article class="card p-4 p-md-5 mx-auto" style="max-width:760px">
  <header class="text-center border-bottom border-secondary-subtle pb-3 mb-4"><h2 class="fw-bold mb-1">TOKOKU</h2><p class="text-muted mb-0">Invoice Penjualan</p></header>
  <div class="row mb-4"><div class="col-6"><strong>No. Transaksi</strong><br><?= e($transaction['no_transaksi']) ?><br><span class="text-muted"><?= e($transaction['tanggal']) ?></span></div><div class="col-6 text-end"><strong>Kasir</strong><br><?= e($transaction['kasir']) ?><br><span class="text-muted">Pelanggan: <?= e($transaction['pelanggan'] ?? 'Umum') ?></span></div></div>
  <table class="table"><thead><tr><th>Barang</th><th class="text-end">Harga</th><th class="text-center">Qty</th><th class="text-end">Subtotal</th></tr></thead><tbody><?php foreach ($items as $item): ?><tr><td><strong><?= e($item['nama_barang']) ?></strong><small class="d-block text-muted"><?= e($item['kode_barang']) ?></small></td><td class="text-end">Rp <?= number_format((float) $item['harga'], 0, ',', '.') ?></td><td class="text-center"><?= e((string) $item['qty']) ?></td><td class="text-end">Rp <?= number_format((float) $item['subtotal'], 0, ',', '.') ?></td></tr><?php endforeach; ?></tbody></table>
  <div class="ms-auto" style="max-width:300px"><div class="d-flex justify-content-between"><span>Total</span><strong>Rp <?= number_format((float) $transaction['total'], 0, ',', '.') ?></strong></div><div class="d-flex justify-content-between"><span>Bayar</span><span>Rp <?= number_format((float) $transaction['bayar'], 0, ',', '.') ?></span></div><div class="d-flex justify-content-between border-top border-secondary-subtle pt-2 mt-2"><span>Kembalian</span><strong>Rp <?= number_format((float) $transaction['kembalian'], 0, ',', '.') ?></strong></div></div>
  <p class="text-center text-muted mt-5 mb-0">Terima kasih atas kunjungan Anda.</p>
</article>

<?php if ($shouldPrint): ?><script>window.addEventListener('load', () => window.print());</script><?php endif; ?>
<?php require dirname(__DIR__) . '/includes/footer.php'; ?>
