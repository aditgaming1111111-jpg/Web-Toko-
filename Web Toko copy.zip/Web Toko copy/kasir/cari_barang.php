<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/config/bootstrap.php';

require_login(['kasir']);
header('Content-Type: application/json; charset=utf-8');

$term = trim((string) ($_GET['q'] ?? ''));
if (mb_strlen($term) < 1) {
    echo '[]';
    exit;
}

$term = mb_substr($term, 0, 50);
$statement = $pdo->prepare(
    'SELECT id_barang, kode_barang, nama_barang, harga, stok, satuan
     FROM barang
     WHERE stok > 0 AND (kode_barang LIKE ? OR nama_barang LIKE ?)
     ORDER BY nama_barang
     LIMIT 12'
);
$statement->execute(['%' . $term . '%', '%' . $term . '%']);

echo json_encode($statement->fetchAll(), JSON_UNESCAPED_UNICODE);
