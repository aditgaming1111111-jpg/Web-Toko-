<?php
require_once dirname(__DIR__) . '/config/bootstrap.php';
$user = require_login(['kasir']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    try {
        $cart = json_decode((string) ($_POST['cart'] ?? ''), true, 512, JSON_THROW_ON_ERROR);
        $paid = input_string('bayar', 15);
        $customerId = filter_input(INPUT_POST, 'id_pelanggan', FILTER_VALIDATE_INT) ?: null;
        if (!is_array($cart) || !$cart || !valid_decimal($paid)) throw new RuntimeException('Keranjang dan nominal pembayaran wajib valid.');

        $pdo->beginTransaction();
        $total = 0; $verified = [];
        $find = $pdo->prepare('SELECT id_barang, kode_barang, nama_barang, harga, stok FROM barang WHERE id_barang = ? FOR UPDATE');
        foreach ($cart as $row) {
            $id = filter_var($row['id_barang'] ?? null, FILTER_VALIDATE_INT);
            $qty = filter_var($row['qty'] ?? null, FILTER_VALIDATE_INT);
            if (!$id || !$qty || $qty < 1) throw new RuntimeException('Data barang tidak valid.');
            $find->execute([$id]); $item = $find->fetch();
            if (!$item || $item['stok'] < $qty) throw new RuntimeException('Stok barang tidak mencukupi. Silakan periksa keranjang.');
            $subtotal = (float)$item['harga'] * $qty;
            $total += $subtotal; $verified[] = [$item, $qty, $subtotal];
        }
        $payment = (float)$paid;
        if ($payment < $total) throw new RuntimeException('Uang pembayaran kurang.');

        $prefix = 'TRX-' . date('Ymd') . '-';
        $last = $pdo->prepare('SELECT no_transaksi FROM transaksi WHERE no_transaksi LIKE ? ORDER BY id_transaksi DESC LIMIT 1 FOR UPDATE');
        $last->execute([$prefix . '%']);
        $lastNo = (string)$last->fetchColumn();
        $number = $prefix . str_pad((string)($lastNo ? (int)substr($lastNo, -4) + 1 : 1), 4, '0', STR_PAD_LEFT);
        $change = $payment - $total;
        $insert = $pdo->prepare('INSERT INTO transaksi (no_transaksi,id_user,id_pelanggan,total,bayar,kembalian) VALUES (?,?,?,?,?,?)');
        $insert->execute([$number, $user['id_user'], $customerId, $total, $payment, $change]);
        $transactionId = (int)$pdo->lastInsertId();
        $detail = $pdo->prepare('INSERT INTO detail_transaksi (id_transaksi,id_barang,harga,qty,subtotal) VALUES (?,?,?,?,?)');
        $reduce = $pdo->prepare('UPDATE barang SET stok = stok - ? WHERE id_barang = ? AND stok >= ?');
        foreach ($verified as [$item, $qty, $subtotal]) {
            $detail->execute([$transactionId, $item['id_barang'], $item['harga'], $qty, $subtotal]);
            $reduce->execute([$qty, $item['id_barang'], $qty]);
            if ($reduce->rowCount() !== 1) throw new RuntimeException('Stok berubah. Silakan ulangi transaksi.');
        }
        $pdo->commit();
        audit($pdo, (int)$user['id_user'], 'Menyimpan transaksi ' . $number);
        flash('success', 'Transaksi berhasil disimpan. Silakan cetak invoice dari detail transaksi.');
        redirect('kasir/detail_transaksi.php?saved=' . $transactionId);
    } catch (Throwable $e) {
        if ($pdo->inTransaction()) $pdo->rollBack();
        flash('error', $e instanceof JsonException ? 'Keranjang tidak valid.' : $e->getMessage());
        redirect('kasir/transaksi.php');
    }
}

$customers = $pdo->query('SELECT id_pelanggan,nama FROM pelanggan ORDER BY nama')->fetchAll();
$products = $pdo->query('SELECT id_barang,kode_barang,nama_barang,harga,stok,satuan FROM barang WHERE stok > 0 ORDER BY nama_barang')->fetchAll();
$pageTitle = 'Transaksi'; require dirname(__DIR__) . '/includes/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-4"><div><h1 class="section-title mb-1">Transaksi Baru</h1><p class="text-muted mb-0">Pilih barang dari daftar, lalu masukkan pembayaran.</p></div><div class="text-end text-muted small">Kasir: <strong class="text-white"><?= e($user['nama']) ?></strong><br><?= e(date('d-m-Y H:i:s')) ?></div></div>
<form method="post" id="transactionForm"><?= csrf_field() ?><input type="hidden" name="cart" id="cartInput"><div class="row g-4"><div class="col-lg-7"><div class="card p-4 mb-4"><label class="form-label" for="productSearch">Cari &amp; Tambah Barang</label><input class="form-control form-control-lg" id="productSearch" autocomplete="off" placeholder="Ketik kode atau nama barang..."><div class="mt-3" id="productList"></div><?php if (!$products): ?><div class="alert alert-warning mb-0">Tidak ada barang dengan stok tersedia. Tambahkan stok dari menu Barang.</div><?php endif; ?></div><div class="card p-3"><h2 class="h5 mb-3">Keranjang</h2><div class="table-responsive"><table class="table align-middle"><thead><tr><th>Kode</th><th>Nama</th><th class="text-end">Harga</th><th style="width:115px">Qty</th><th class="text-end">Subtotal</th><th></th></tr></thead><tbody id="cartRows"></tbody></table></div></div></div><div class="col-lg-5"><div class="card p-4"><div class="mb-3"><label class="form-label">Pelanggan</label><select class="form-select" name="id_pelanggan"><option value="">Umum / Tanpa pelanggan</option><?php foreach ($customers as $c): ?><option value="<?= (int)$c['id_pelanggan'] ?>"><?= e($c['nama']) ?></option><?php endforeach; ?></select></div><hr><div class="d-flex justify-content-between fs-4 fw-bold mb-3"><span>Total</span><span id="totalText">Rp 0</span></div><label class="form-label">Bayar</label><input class="form-control form-control-lg" type="number" min="0" step="1" id="payment" name="bayar" required><div class="d-flex justify-content-between mt-3"><span class="text-muted">Kembalian</span><strong id="changeText">Rp 0</strong></div><div id="paymentWarning" class="text-warning small mt-2 d-none">Uang pembayaran kurang.</div><div class="d-flex gap-2 mt-4"><button class="btn btn-outline-light w-50" type="button" id="resetCart">Reset</button><button class="btn btn-primary w-50" type="submit">Simpan Transaksi</button></div></div></div></div></form>
<script>
const products = <?= json_encode($products, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
let cart = [];
const productSearch = document.getElementById('productSearch'), productList = document.getElementById('productList'), cartRows = document.getElementById('cartRows'), cartInput = document.getElementById('cartInput'), payment = document.getElementById('payment'), totalText = document.getElementById('totalText'), changeText = document.getElementById('changeText'), paymentWarning = document.getElementById('paymentWarning'), resetCart = document.getElementById('resetCart'), transactionForm = document.getElementById('transactionForm');
const rup = n => new Intl.NumberFormat('id-ID',{style:'currency',currency:'IDR',maximumFractionDigits:0}).format(n);
const esc = s => String(s).replace(/[&<>'"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;',"'":'&#39;','"':'&quot;'}[c]));
function addProduct(id){const item=products.find(x=>+x.id_barang===+id);if(!item)return;const old=cart.find(x=>+x.id_barang===+id);if(old){if(old.qty<+old.stok)old.qty++}else cart.push({...item,harga:+item.harga,stok:+item.stok,qty:1});renderCart()}
function renderProducts(){const q=productSearch.value.trim().toLowerCase();const visible=products.filter(x=>(x.kode_barang+' '+x.nama_barang).toLowerCase().includes(q));productList.innerHTML=visible.length?'<div class="list-group">'+visible.map(x=>`<button type="button" class="list-group-item list-group-item-action bg-transparent text-white border-secondary-subtle product-btn" data-id="${+x.id_barang}"><strong>${esc(x.kode_barang)}</strong> — ${esc(x.nama_barang)}<span class="float-end">${rup(x.harga)} · stok ${+x.stok} ${esc(x.satuan)}</span></button>`).join('')+'</div>':'<div class="text-muted small py-2">Barang tidak ditemukan.</div>'}
function renderCart(){const body=document.getElementById('cartRows');body.innerHTML=cart.length?cart.map((x,i)=>`<tr><td>${esc(x.kode_barang)}</td><td>${esc(x.nama_barang)}<small class="d-block text-muted">Stok: ${x.stok}</small></td><td class="text-end">${rup(x.harga)}</td><td><input class="form-control form-control-sm qty" data-index="${i}" type="number" min="1" max="${x.stok}" value="${x.qty}"></td><td class="text-end">${rup(x.harga*x.qty)}</td><td><button type="button" class="btn btn-sm btn-outline-danger remove" data-index="${i}"><i class="bi bi-x"></i></button></td></tr>`).join(''):'<tr><td colspan="6" class="text-center text-muted py-4">Keranjang masih kosong.</td></tr>';const total=cart.reduce((sum,x)=>sum+x.harga*x.qty,0);totalText.textContent=rup(total);const change=(+payment.value||0)-total;changeText.textContent=rup(Math.max(change,0));paymentWarning.classList.toggle('d-none',change>=0);cartInput.value=JSON.stringify(cart.map(x=>({id_barang:x.id_barang,qty:x.qty})))}
productSearch.addEventListener('input',renderProducts);productList.addEventListener('click',e=>{const button=e.target.closest('.product-btn');if(button)addProduct(button.dataset.id)});cartRows.addEventListener('input',e=>{if(e.target.matches('.qty')){const x=cart[e.target.dataset.index];x.qty=Math.min(x.stok,Math.max(1,+e.target.value||1));renderCart()}});cartRows.addEventListener('click',e=>{const button=e.target.closest('.remove');if(button){cart.splice(button.dataset.index,1);renderCart()}});payment.addEventListener('input',renderCart);resetCart.addEventListener('click',()=>{cart=[];payment.value='';renderCart()});transactionForm.addEventListener('submit',e=>{const total=cart.reduce((sum,x)=>sum+x.harga*x.qty,0);if(!cart.length){e.preventDefault();alert('Keranjang kosong\nTambahkan minimal satu barang.')}else if((+payment.value||0)<total){e.preventDefault();alert('Pembayaran kurang')}});renderProducts();renderCart();
</script>
<?php require dirname(__DIR__) . '/includes/footer.php'; ?>
