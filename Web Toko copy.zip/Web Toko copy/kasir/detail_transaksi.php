<?php
declare(strict_types=1);

require_once dirname(__DIR__) . '/config/bootstrap.php';

$user = require_login(['kasir']);
$search = trim((string) ($_GET['q'] ?? ''));
$startDate = trim((string) ($_GET['start'] ?? ''));
$endDate = trim((string) ($_GET['end'] ?? ''));
$savedId = filter_input(INPUT_GET, 'saved', FILTER_VALIDATE_INT);
$savedTransaction = null;

if ($savedId) {
    $savedStatement = $pdo->prepare(
        'SELECT id_transaksi, no_transaksi, total
         FROM transaksi
         WHERE id_transaksi = ? AND id_user = ?'
    );
    $savedStatement->execute([$savedId, $user['id_user']]);
    $savedTransaction = $savedStatement->fetch();
}

$sql = 'SELECT t.*, p.nama AS pelanggan
        FROM transaksi t
        LEFT JOIN pelanggan p ON p.id_pelanggan = t.id_pelanggan
        WHERE t.id_user = ?';
$parameters = [$user['id_user']];

if ($search !== '') {
    $sql .= ' AND t.no_transaksi LIKE ?';
    $parameters[] = '%' . mb_substr($search, 0, 30) . '%';
}

if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $startDate)) {
    $sql .= ' AND DATE(t.tanggal) >= ?';
    $parameters[] = $startDate;
}

if (preg_match('/^\d{4}-\d{2}-\d{2}$/', $endDate)) {
    $sql .= ' AND DATE(t.tanggal) <= ?';
    $parameters[] = $endDate;
}

$sql .= ' ORDER BY t.tanggal DESC';
$statement = $pdo->prepare($sql);
$statement->execute($parameters);
$transactions = $statement->fetchAll();

$pageTitle = 'Detail Transaksi';
require dirname(__DIR__) . '/includes/header.php';
?>

<div class="mb-4">
  <h1 class="section-title mb-1">Detail Transaksi</h1>
  <p class="text-muted mb-0">Riwayat transaksi Anda.</p>
</div>

<?php if ($savedTransaction): ?>
  <div class="alert alert-success d-flex justify-content-between align-items-center">
    <span><strong><?= e($savedTransaction['no_transaksi']) ?></strong> berhasil disimpan.</span>
    <a class="btn btn-sm btn-success" href="<?= url('kasir/invoice.php?id=' . (int) $savedTransaction['id_transaksi'] . '&print=1') ?>">
      <i class="bi bi-printer"></i> Cetak Invoice
    </a>
  </div>
<?php endif; ?>

<div class="card p-3 mb-4">
  <form class="row g-3" method="get">
    <div class="col-md-4">
      <label class="form-label" for="searchTransaction">Cari No. Transaksi</label>
      <input class="form-control" id="searchTransaction" name="q" value="<?= e($search) ?>">
    </div>
    <div class="col-md-3">
      <label class="form-label" for="startDate">Tanggal Awal</label>
      <input class="form-control" id="startDate" name="start" type="date" value="<?= e($startDate) ?>">
    </div>
    <div class="col-md-3">
      <label class="form-label" for="endDate">Tanggal Akhir</label>
      <input class="form-control" id="endDate" name="end" type="date" value="<?= e($endDate) ?>">
    </div>
    <div class="col-md-2 d-flex align-items-end gap-2">
      <button class="btn btn-primary">Filter</button>
      <a class="btn btn-outline-light" href="<?= url('kasir/detail_transaksi.php') ?>">Reset</a>
    </div>
  </form>
</div>

<div class="card p-3">
  <div class="table-responsive">
    <table class="table data-table align-middle">
      <thead>
        <tr><th>No. Transaksi</th><th>Tanggal</th><th>Pelanggan</th><th>Total</th><th>Bayar</th><th>Aksi</th></tr>
      </thead>
      <tbody>
        <?php foreach ($transactions as $transaction): ?>
          <tr>
            <td><?= e($transaction['no_transaksi']) ?></td>
            <td><?= e($transaction['tanggal']) ?></td>
            <td><?= e($transaction['pelanggan'] ?? 'Umum') ?></td>
            <td>Rp <?= number_format((float) $transaction['total'], 0, ',', '.') ?></td>
            <td>Rp <?= number_format((float) $transaction['bayar'], 0, ',', '.') ?></td>
            <td><a class="btn btn-sm btn-outline-light" href="<?= url('kasir/invoice.php?id=' . (int) $transaction['id_transaksi']) ?>"><i class="bi bi-receipt"></i> Invoice</a></td>
          </tr>
        <?php endforeach; ?>
      </tbody>
    </table>
  </div>
</div>

<?php require dirname(__DIR__) . '/includes/footer.php'; ?>
