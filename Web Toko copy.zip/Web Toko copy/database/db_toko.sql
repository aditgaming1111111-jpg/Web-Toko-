CREATE DATABASE IF NOT EXISTS db_toko CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE db_toko;

CREATE TABLE IF NOT EXISTS users (
  id_user INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  username VARCHAR(50) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('admin','kasir','gudang') NOT NULL,
  status ENUM('aktif','nonaktif') NOT NULL DEFAULT 'aktif',
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS pelanggan (
  id_pelanggan INT AUTO_INCREMENT PRIMARY KEY,
  nama VARCHAR(100) NOT NULL,
  alamat TEXT NULL,
  telepon VARCHAR(20) NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS barang (
  id_barang INT AUTO_INCREMENT PRIMARY KEY,
  kode_barang VARCHAR(20) NOT NULL UNIQUE,
  nama_barang VARCHAR(150) NOT NULL,
  kategori VARCHAR(100) NOT NULL,
  harga DECIMAL(15,2) NOT NULL DEFAULT 0,
  stok INT NOT NULL DEFAULT 0,
  satuan VARCHAR(30) NOT NULL,
  created_at TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT chk_barang_harga CHECK (harga >= 0),
  CONSTRAINT chk_barang_stok CHECK (stok >= 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS transaksi (
  id_transaksi INT AUTO_INCREMENT PRIMARY KEY,
  no_transaksi VARCHAR(30) NOT NULL UNIQUE,
  id_user INT NOT NULL,
  id_pelanggan INT NULL,
  tanggal DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  total DECIMAL(15,2) NOT NULL,
  bayar DECIMAL(15,2) NOT NULL,
  kembalian DECIMAL(15,2) NOT NULL,
  CONSTRAINT fk_transaksi_user FOREIGN KEY (id_user) REFERENCES users(id_user) ON UPDATE CASCADE,
  CONSTRAINT fk_transaksi_pelanggan FOREIGN KEY (id_pelanggan) REFERENCES pelanggan(id_pelanggan) ON UPDATE CASCADE
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS detail_transaksi (
  id_detail INT AUTO_INCREMENT PRIMARY KEY,
  id_transaksi INT NOT NULL,
  id_barang INT NOT NULL,
  harga DECIMAL(15,2) NOT NULL,
  qty INT NOT NULL,
  subtotal DECIMAL(15,2) NOT NULL,
  CONSTRAINT fk_detail_transaksi FOREIGN KEY (id_transaksi) REFERENCES transaksi(id_transaksi) ON DELETE CASCADE,
  CONSTRAINT fk_detail_barang FOREIGN KEY (id_barang) REFERENCES barang(id_barang),
  CONSTRAINT chk_detail_qty CHECK (qty > 0)
) ENGINE=InnoDB;

CREATE TABLE IF NOT EXISTS log_aktivitas (
  id_log INT AUTO_INCREMENT PRIMARY KEY,
  id_user INT NULL,
  aktivitas VARCHAR(255) NOT NULL,
  ip_address VARCHAR(100) NOT NULL,
  created_at DATETIME NOT NULL DEFAULT CURRENT_TIMESTAMP,
  CONSTRAINT fk_log_user FOREIGN KEY (id_user) REFERENCES users(id_user)
) ENGINE=InnoDB;

CREATE INDEX idx_barang_nama ON barang(nama_barang);
CREATE INDEX idx_barang_kode ON barang(kode_barang);
CREATE INDEX idx_transaksi_tanggal ON transaksi(tanggal);
CREATE INDEX idx_log_tanggal ON log_aktivitas(created_at);

INSERT IGNORE INTO users (nama,username,password,role,status) VALUES
('Administrator','admin','$2y$12$l9ipQeT2aiPPYJLuVfkFyOiRXkGGb3.xBZQvdayWFcQIkI50f1ZHq','admin','aktif');
INSERT IGNORE INTO pelanggan (id_pelanggan,nama,alamat,telepon) VALUES (1,'Umum','-','-');
INSERT IGNORE INTO barang (kode_barang,nama_barang,kategori,harga,stok,satuan) VALUES
('BRG001','Pensil','ATK',3000,120,'PCS'),('BRG002','Pulpen','ATK',5000,80,'PCS'),('BRG003','Buku Tulis','ATK',12000,60,'PCS'),('BRG004','Penghapus','ATK',2500,100,'PCS');

DROP VIEW IF EXISTS laporan_penjualan;
CREATE VIEW laporan_penjualan AS
SELECT t.no_transaksi,t.tanggal,u.nama AS kasir,SUM(d.qty) AS total_barang,t.total,t.bayar,t.kembalian
FROM transaksi t JOIN users u ON u.id_user=t.id_user JOIN detail_transaksi d ON d.id_transaksi=t.id_transaksi
GROUP BY t.id_transaksi,t.no_transaksi,t.tanggal,u.nama,t.total,t.bayar,t.kembalian;

DROP VIEW IF EXISTS stok_barang;
CREATE VIEW stok_barang AS SELECT kode_barang,nama_barang,kategori,stok,harga FROM barang;
