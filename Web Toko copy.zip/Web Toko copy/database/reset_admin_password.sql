-- Jalankan hanya untuk memperbaiki akun admin bawaan dari SQL versi lama.
UPDATE users
SET password = '$2y$12$l9ipQeT2aiPPYJLuVfkFyOiRXkGGb3.xBZQvdayWFcQIkI50f1ZHq',
    status = 'aktif'
WHERE username = 'admin' AND role = 'admin';
