# TokoKu — PHP Native

1. Jalankan Apache dan MySQL dari XAMPP.
2. Import [`database/db_toko.sql`](database/db_toko.sql) melalui phpMyAdmin.
3. Buka `http://localhost/Web%20Toko/`.
4. Login awal: **admin** / **admin123**.

Konfigurasi koneksi berada di `config/bootstrap.php` (`DB_HOST`, `DB_NAME`, `DB_USER`, `DB_PASS`). Ubah hanya bila konfigurasi MySQL lokal Anda berbeda.

Fitur keamanan yang sudah diterapkan: session dengan timeout 30 menit dan regenerasi ID, password hash/verifikasi, PDO prepared statement, token CSRF untuk seluruh aksi perubahan data, validasi server/client, escape HTML, pembatasan akses berdasarkan peran, serta audit log.

> Untuk instalasi baru gunakan file SQL di atas. Jika Anda telah mengimpor SQL lama yang memakai hash contoh, jalankan `database/reset_admin_password.sql` sekali agar akun `admin` dapat masuk dengan password `admin123`.
