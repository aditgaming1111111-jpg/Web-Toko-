<?php
$role = $user['role'];
$menus = [
 'admin' => [['dashboard.php','Dashboard','speedometer2'],['admin/user.php','Kelola User','people'],['admin/laporan.php','Laporan','bar-chart'],['admin/log.php','Log Aktivitas','journal-text']],
 'kasir' => [['kasir/transaksi.php','Transaksi','cart3'],['kasir/detail_transaksi.php','Detail Transaksi','receipt'],['kasir/invoice.php','Invoice','file-earmark-text']],
 'gudang' => [['gudang/barang.php','Barang','box-seam']],
];
$current = basename($_SERVER['PHP_SELF']);
?>
<aside class="sidebar" id="sidebar">
  <?php
    $brandLink = 'dashboard.php';
    if ($role === 'kasir') $brandLink = 'kasir/transaksi.php';
    if ($role === 'gudang') $brandLink = 'gudang/barang.php';
  ?>
  <a class="brand" href="<?= url($brandLink) ?>"><span class="brand-mark"><i class="bi bi-bag-check"></i></span><span>TOKO<span>KU</span></span></a>
  <div class="nav flex-column gap-1 mt-4">
    <?php foreach ($menus[$role] as [$link,$label,$icon]): ?>
      <a class="nav-link <?= str_ends_with($link, $current) ? 'active' : '' ?>" href="<?= url($link) ?>"><i class="bi bi-<?= e($icon) ?>"></i><?= e($label) ?></a>
    <?php endforeach; ?>
  </div>
  <form method="post" action="<?= url('logout.php') ?>" class="mt-auto logout-form"><?= csrf_field() ?><button class="nav-link logout-btn" type="submit"><i class="bi bi-box-arrow-left"></i>Logout</button></form>
</aside>
