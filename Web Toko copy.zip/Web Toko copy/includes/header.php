<?php
/** @var string $pageTitle */
/** @var array $user */
$flash = pull_flash();
?>
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
  <title><?= e($pageTitle ?? 'TokoKu') ?> | TokoKu</title>
  <link rel="preconnect" href="https://fonts.googleapis.com">
  <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
  <link href="https://fonts.googleapis.com/css2?family=Inter:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
  <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet">
  <link href="https://cdn.datatables.net/2.1.8/css/dataTables.bootstrap5.css" rel="stylesheet">
  <link href="<?= url('assets/css/variables.css') ?>" rel="stylesheet">
  <link href="<?= url('assets/css/app.css') ?>" rel="stylesheet">
  <link href="<?= url('assets/css/components.css') ?>" rel="stylesheet">
  <link href="<?= url('assets/css/responsive.css') ?>" rel="stylesheet">
</head>
<body>
<div class="app-shell">
  <?php require __DIR__ . '/sidebar.php'; ?>
  <main class="main-content">
    <nav class="topbar">
          <div class="d-flex align-items-center gap-3">
            <button class="btn btn-link d-lg-none text-dark p-0" id="sidebarToggle" aria-label="Buka menu"><i class="bi bi-list fs-3"></i></button>
            <?php
              $brandLink = 'dashboard.php';
              if (!empty($user['role'])) {
                if ($user['role'] === 'kasir') $brandLink = 'kasir/transaksi.php';
                if ($user['role'] === 'gudang') $brandLink = 'gudang/barang.php';
              }
            ?>
            <a class="navbar-brand d-flex align-items-center" href="<?= url($brandLink) ?>"><span class="brand-mark"><i class="bi bi-bag-check"></i></span></a>
          </div>
          <!-- Horizontal nav removed per request: no direct page links in topbar -->
      <div class="topbar-user"><div class="text-end lh-sm"><strong class="d-block"><?= e($user['nama']) ?></strong><small class="text-muted">Akun aktif</small></div><span class="user-avatar"><?= e(strtoupper(mb_substr($user['nama'], 0, 1))) ?></span><span class="role-badge"><?= e($user['role']) ?></span></div>
    </nav>
    <div class="container-fluid py-4">
      <?php if ($flash): ?><div class="flash-data" data-type="<?= e($flash['type']) ?>" data-message="<?= e($flash['message']) ?>"></div><?php endif; ?>
