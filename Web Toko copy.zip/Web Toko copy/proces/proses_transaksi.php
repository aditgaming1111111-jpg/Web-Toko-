<?php
// Endpoint lama dipertahankan agar URL tidak menghasilkan halaman kosong.
require_once dirname(__DIR__) . '/kasir/transaksi.php';
