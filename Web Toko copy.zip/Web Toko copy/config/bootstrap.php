<?php
declare(strict_types=1);

/** Konfigurasi dasar aplikasi. Ubah kredensial berikut bila MySQL Anda berbeda. */
const DB_HOST = '127.0.0.1';
const DB_NAME = 'db_toko';
const DB_USER = 'root';
const DB_PASS = '';
const SESSION_TIMEOUT = 1800; // 30 menit

date_default_timezone_set('Asia/Jakarta');

if (PHP_SAPI !== 'cli' && !headers_sent()) {
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: DENY');
    header('Referrer-Policy: strict-origin-when-cross-origin');
    header('Permissions-Policy: camera=(), microphone=(), geolocation=()');
}

/* Menentukan URL proyek secara otomatis saat diletakkan di htdocs XAMPP. */
$documentRoot = realpath($_SERVER['DOCUMENT_ROOT'] ?? '') ?: '';
$appRoot = realpath(dirname(__DIR__)) ?: dirname(__DIR__);
$relativeRoot = $documentRoot !== '' && str_starts_with($appRoot, $documentRoot)
    ? substr($appRoot, strlen($documentRoot)) : '';
define('BASE_URL', rtrim(str_replace(' ', '%20', $relativeRoot), '/'));

if (session_status() !== PHP_SESSION_ACTIVE) {
    session_name('toko_session');
    session_set_cookie_params([
        'lifetime' => 0,
        'path' => BASE_URL . '/',
        'secure' => (!empty($_SERVER['HTTPS']) && $_SERVER['HTTPS'] !== 'off'),
        'httponly' => true,
        'samesite' => 'Lax',
    ]);
    session_start();
}

try {
    $pdo = new PDO(
        'mysql:host=' . DB_HOST . ';dbname=' . DB_NAME . ';charset=utf8mb4',
        DB_USER,
        DB_PASS,
        [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION,
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            PDO::ATTR_EMULATE_PREPARES => false,
            PDO::ATTR_TIMEOUT => 5,
        ]
    );
} catch (PDOException $exception) {
    http_response_code(500);
    exit('Koneksi database gagal. Periksa konfigurasi di config/bootstrap.php dan pastikan database db_toko telah diimpor.');
}

require_once __DIR__ . '/auth.php';
