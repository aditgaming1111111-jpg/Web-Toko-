<?php
declare(strict_types=1);

function url(string $path = ''): string {
    return BASE_URL . '/' . ltrim($path, '/');
}

function redirect(string $path): never {
    header('Location: ' . url($path));
    exit;
}

function e(?string $value): string {
    return htmlspecialchars((string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8');
}

function csrf_token(): string {
    if (empty($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
    return $_SESSION['csrf_token'];
}

function csrf_field(): string {
    return '<input type="hidden" name="csrf_token" value="' . e(csrf_token()) . '">';
}

function verify_csrf(): void {
    $token = $_POST['csrf_token'] ?? '';
    if (!is_string($token) || !hash_equals($_SESSION['csrf_token'] ?? '', $token)) {
        http_response_code(419);
        exit('Permintaan tidak valid atau sesi telah berakhir. Silakan muat ulang halaman.');
    }
}

function flash(string $type, string $message): void {
    $_SESSION['flash'] = ['type' => $type, 'message' => $message];
}

function pull_flash(): ?array {
    $flash = $_SESSION['flash'] ?? null;
    unset($_SESSION['flash']);
    return is_array($flash) ? $flash : null;
}

function current_user(): ?array {
    return isset($_SESSION['user']) && is_array($_SESSION['user']) ? $_SESSION['user'] : null;
}

function is_logged_in(): bool {
    return current_user() !== null;
}

function end_session(string $message = 'Sesi Anda telah berakhir. Silakan masuk kembali.'): never {
    $_SESSION = [];
    if (ini_get('session.use_cookies')) {
        $p = session_get_cookie_params();
        setcookie(session_name(), '', time() - 42000, $p['path'], $p['domain'], (bool)$p['secure'], (bool)$p['httponly']);
    }
    session_destroy();
    session_write_close();
    session_id('');
    session_start();
    flash('warning', $message);
    redirect('login.php');
}

function require_login(?array $roles = null): array {
    $user = current_user();
    if (!$user) redirect('login.php');
    if (time() - (int)($_SESSION['last_activity'] ?? 0) > SESSION_TIMEOUT) {
        end_session();
    }
    $_SESSION['last_activity'] = time();
    if (empty($_SESSION['regenerated_at']) || time() - (int)$_SESSION['regenerated_at'] > 900) {
        session_regenerate_id(true);
        $_SESSION['regenerated_at'] = time();
    }
    if ($roles !== null && !in_array($user['role'], $roles, true)) {
        http_response_code(403);
        exit('403 - Anda tidak memiliki akses ke halaman ini.');
    }
    return $user;
}

function audit(PDO $pdo, ?int $userId, string $activity): void {
    try {
        $stmt = $pdo->prepare('INSERT INTO log_aktivitas (id_user, aktivitas, ip_address) VALUES (:id_user, :aktivitas, :ip)');
        $stmt->execute([
            ':id_user' => $userId,
            ':aktivitas' => mb_substr($activity, 0, 255),
            ':ip' => mb_substr($_SERVER['REMOTE_ADDR'] ?? 'unknown', 0, 100),
        ]);
    } catch (Throwable $exception) {
        error_log('Audit log gagal: ' . $exception->getMessage());
    }
}

function input_string(string $key, int $max = 255): string {
    $value = trim((string)($_POST[$key] ?? ''));
    return mb_substr($value, 0, $max);
}

function valid_decimal(string $value): bool {
    return (bool)preg_match('/^\d+(?:\.\d{1,2})?$/', $value);
}
