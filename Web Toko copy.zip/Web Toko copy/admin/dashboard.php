<?php
require_once dirname(__DIR__) . '/config/bootstrap.php';
require_login(['admin']);
require_once dirname(__DIR__) . '/dashboard.php';
