<?php
require_once dirname(__DIR__) . '/config/bootstrap.php';
$user = require_login(['admin']);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $action = input_string('action', 12);
    $id = filter_input(INPUT_POST, 'id_user', FILTER_VALIDATE_INT);
    try {
        if ($action === 'delete' && $id) {
            if ($id === (int)$user['id_user']) throw new RuntimeException('Akun Anda sendiri tidak dapat dihapus.');
            $target = $pdo->prepare('SELECT role FROM users WHERE id_user = ?'); $target->execute([$id]);
            if (($target->fetchColumn() ?: '') === 'admin') throw new RuntimeException('Akun admin utama tidak dapat dihapus.');
            $stmt = $pdo->prepare('DELETE FROM users WHERE id_user = ?'); $stmt->execute([$id]);
            audit($pdo,(int)$user['id_user'],'Menghapus user ID ' . $id); flash('success','User berhasil dihapus.');
        } elseif (in_array($action,['create','update'],true)) {
            $name=input_string('nama',100); $username=input_string('username',50); $role=input_string('role',10); $status=input_string('status',10); $password=(string)($_POST['password']??'');
            if ($name==='' || !preg_match('/^[A-Za-z0-9._-]{3,50}$/',$username) || !in_array($role,['kasir','gudang','admin'],true) || !in_array($status,['aktif','nonaktif'],true)) throw new RuntimeException('Data user tidak valid. Username minimal 3 karakter dan hanya huruf, angka, titik, garis bawah, atau strip.');
            if ($action==='create') {
                if (strlen($password)<8) throw new RuntimeException('Password minimal 8 karakter.');
                $stmt=$pdo->prepare('INSERT INTO users(nama,username,password,role,status) VALUES(?,?,?,?,?)');
                $stmt->execute([$name,$username,password_hash($password,PASSWORD_DEFAULT),$role,$status]);
                audit($pdo,(int)$user['id_user'],'Menambah user ' . $username); flash('success','User berhasil ditambahkan.');
            } else {
                if (!$id) throw new RuntimeException('User tidak ditemukan.');
                if ($password!=='' && strlen($password)<8) throw new RuntimeException('Password minimal 8 karakter.');
                $target=$pdo->prepare('SELECT role FROM users WHERE id_user=?');$target->execute([$id]);$targetRole=$target->fetchColumn();
                if (!$targetRole) throw new RuntimeException('User tidak ditemukan.');
                if ($targetRole==='admin') throw new RuntimeException('Role akun admin utama tidak dapat diubah dari halaman ini.');
                if ($password==='') {$stmt=$pdo->prepare('UPDATE users SET nama=?,username=?,role=?,status=? WHERE id_user=?');$stmt->execute([$name,$username,$role,$status,$id]);}
                else {$stmt=$pdo->prepare('UPDATE users SET nama=?,username=?,password=?,role=?,status=? WHERE id_user=?');$stmt->execute([$name,$username,password_hash($password,PASSWORD_DEFAULT),$role,$status,$id]);}
                audit($pdo,(int)$user['id_user'],'Mengubah user ID ' . $id); flash('success','User berhasil diperbarui.');
            }
        } else throw new RuntimeException('Aksi tidak valid.');
    } catch (PDOException $e) { flash('error', $e->getCode()==='23000' ? 'Username sudah digunakan.' : 'Data gagal disimpan.'); }
      catch (Throwable $e) { flash('error',$e->getMessage()); }
    redirect('admin/user.php');
}
$users=$pdo->query('SELECT id_user,nama,username,role,status,created_at FROM users ORDER BY created_at DESC')->fetchAll();
$pageTitle='Kelola User'; require dirname(__DIR__).'/includes/header.php';
?>
<div class="d-flex justify-content-between align-items-center mb-4"><div><h1 class="section-title mb-1">Kelola User</h1><p class="text-muted mb-0">Tambahkan akun kasir, gudang, atau admin sesuai kebutuhan.</p></div><button class="btn btn-primary no-print" data-bs-toggle="modal" data-bs-target="#userModal"><i class="bi bi-plus-lg me-1"></i> Tambah User</button></div>
<div class="card p-3"><div class="table-responsive"><table class="table data-table align-middle"><thead><tr><th>Nama</th><th>Username</th><th>Role</th><th>Status</th><th>Tanggal Dibuat</th><th class="no-print">Aksi</th></tr></thead><tbody><?php foreach($users as $row): ?><tr><td><?= e($row['nama']) ?></td><td><?= e($row['username']) ?></td><td><span class="badge text-bg-primary"><?= e(ucfirst($row['role'])) ?></span></td><td><span class="badge <?= $row['status']==='aktif'?'text-bg-success':'text-bg-secondary' ?>"><?= e($row['status']) ?></span></td><td><?= e($row['created_at']) ?></td><td class="no-print"><?php if($row['role']!=='admin'): ?><button class="btn btn-sm btn-outline-light edit-user" data-user='<?= e(json_encode($row)) ?>' data-bs-toggle="modal" data-bs-target="#userModal"><i class="bi bi-pencil"></i></button><form method="post" class="d-inline" data-confirm="Hapus user ini?"> <?= csrf_field() ?><input type="hidden" name="action" value="delete"><input type="hidden" name="id_user" value="<?= (int)$row['id_user'] ?>"><button class="btn btn-sm btn-outline-danger"><i class="bi bi-trash"></i></button></form><?php else: ?><span class="text-muted small">Admin utama</span><?php endif; ?></td></tr><?php endforeach; ?></tbody></table></div></div>
<div class="modal fade" id="userModal" tabindex="-1"><div class="modal-dialog"><form method="post" class="modal-content border-secondary needs-validation" novalidate><?= csrf_field() ?><input name="action" id="userAction" type="hidden" value="create"><input name="id_user" id="userId" type="hidden"><div class="modal-header border-secondary"><h2 class="modal-title fs-5" id="modalTitle">Tambah User</h2><button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button></div><div class="modal-body"><div class="mb-3"><label class="form-label">Nama</label><input class="form-control" id="userName" name="nama" maxlength="100" required></div><div class="mb-3"><label class="form-label">Username</label><input class="form-control" id="userUsername" name="username" pattern="[A-Za-z0-9._-]{3,50}" maxlength="50" required></div><div class="mb-3"><label class="form-label">Password <small class="text-muted" id="passwordHint">(minimal 8 karakter)</small></label><input class="form-control" id="userPassword" type="password" name="password" minlength="8"></div><div class="row"><div class="col"><label class="form-label">Role</label><select class="form-select" id="userRole" name="role" required><option value="kasir">Kasir</option><option value="gudang">Gudang</option><option value="admin">Admin</option></select></div><div class="col"><label class="form-label">Status</label><select class="form-select" id="userStatus" name="status"><option value="aktif">Aktif</option><option value="nonaktif">Nonaktif</option></select></div></div></div><div class="modal-footer border-secondary"><button class="btn btn-primary">Simpan</button></div></form></div></div>
<script>const modal=document.getElementById('userModal');modal.addEventListener('show.bs.modal',e=>{const b=e.relatedTarget;if(!b?.classList.contains('edit-user')){document.getElementById('userAction').value='create';document.getElementById('modalTitle').textContent='Tambah User';document.getElementById('userId').value='';document.getElementById('userPassword').required=true;modal.querySelector('form').reset();return}const u=JSON.parse(b.dataset.user);document.getElementById('userAction').value='update';document.getElementById('modalTitle').textContent='Edit User';document.getElementById('userId').value=u.id_user;document.getElementById('userName').value=u.nama;document.getElementById('userUsername').value=u.username;document.getElementById('userRole').value=u.role;document.getElementById('userStatus').value=u.status;document.getElementById('userPassword').required=false;document.getElementById('passwordHint').textContent='(kosongkan bila tidak diubah)'})</script>
<?php require dirname(__DIR__).'/includes/footer.php'; ?>
