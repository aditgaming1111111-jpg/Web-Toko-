document.addEventListener('DOMContentLoaded', () => {
	const flash = document.querySelector('.flash-data');
	if (flash) {
		const msg = flash.dataset.message || '';
		// simple non-blocking toast
		const toast = document.createElement('div');
		toast.textContent = msg;
		Object.assign(toast.style, {
			position: 'fixed',
			top: '18px',
			right: '18px',
			background: 'rgba(0,0,0,0.85)',
			color: '#fff',
			padding: '10px 14px',
			borderRadius: '10px',
			zIndex: 9999,
			opacity: 0,
			transition: 'opacity 180ms ease'
		});
		document.body.appendChild(toast);
		requestAnimationFrame(() => { toast.style.opacity = '1'; });
		setTimeout(() => { toast.style.opacity = '0'; setTimeout(() => toast.remove(), 220); }, 2200);
	}

	document.querySelectorAll('.logout-form').forEach(f => f.addEventListener('submit', e => {
		e.preventDefault();
		if (confirm('Keluar dari aplikasi?')) f.submit();
	}));

	document.querySelectorAll('[data-confirm]').forEach(f => f.addEventListener('submit', e => {
		if (f.dataset.confirmed) return;
		e.preventDefault();
		if (confirm(f.dataset.confirm || 'Lanjutkan?')) { f.dataset.confirmed = '1'; f.submit(); }
	}));

	document.getElementById('sidebarToggle')?.addEventListener('click', () => document.getElementById('sidebar').classList.toggle('show'));

	document.querySelectorAll('.data-table').forEach(t => new DataTable(t, {
		pageLength: 10,
		language: {
			search: 'Cari:',
			lengthMenu: 'Tampilkan _MENU_',
			info: 'Menampilkan _START_–_END_ dari _TOTAL_ data',
			zeroRecords: 'Data tidak ditemukan',
			paginate: { previous: 'Sebelumnya', next: 'Berikutnya' }
		}
	}));
});
