<?php
require_once __DIR__ . '/config/bootstrap.php';
if (is_logged_in()) redirect('dashboard.php');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $username = input_string('username', 50);
    $password = (string)($_POST['password'] ?? '');
    if ($username === '' || $password === '') {
        flash('error', 'Username dan password wajib diisi.'); redirect('login.php');
    }
    $stmt = $pdo->prepare('SELECT id_user, nama, username, password, role, status FROM users WHERE username = :username LIMIT 1');
    $stmt->execute([':username' => $username]);
    $account = $stmt->fetch();
    if (!$account || $account['status'] !== 'aktif' || !password_verify($password, $account['password'])) {
        usleep(300000); // mengurangi brute force sederhana tanpa mengungkap akun
        flash('error', 'Username atau Password Salah'); redirect('login.php');
    }
    session_regenerate_id(true);
    unset($account['password']);
    $_SESSION['user'] = $account;
    $_SESSION['last_activity'] = time();
    $_SESSION['regenerated_at'] = time();
    audit($pdo, (int)$account['id_user'], 'Login ke sistem');
    // Masuk ke halaman sesuai role setelah login.
    $target = 'dashboard.php';
    if ($account['role'] === 'kasir') $target = 'kasir/transaksi.php';
    if ($account['role'] === 'gudang') $target = 'gudang/barang.php';
    redirect($target);
}
$flash = pull_flash();
?>
<!doctype html><html lang="id"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1"><title>Login | TokoKu</title><link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet"><link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.min.css" rel="stylesheet"><link href="<?= url('assets/css/app.css') ?>" rel="stylesheet"></head>
<body class="login-page"><section class="login-card"><div class="text-center mb-4"><div class="brand-mark mx-auto mb-3"><i class="bi bi-bag-check"></i></div><h1 class="h3 fw-bold">Selamat Datang</h1><p class="text-muted mb-0">Masuk untuk mengelola TokoKu</p></div><form method="post" novalidate><?= csrf_field() ?><div class="mb-3"><label class="form-label">Username</label><div class="input-group"><span class="input-group-text bg-transparent border-secondary-subtle text-muted"><i class="bi bi-person"></i></span><input class="form-control" name="username" maxlength="50" autocomplete="username" required autofocus></div></div><div class="mb-4"><label class="form-label">Password</label><div class="input-group"><span class="input-group-text bg-transparent border-secondary-subtle text-muted"><i class="bi bi-lock"></i></span><input class="form-control" type="password" name="password" autocomplete="current-password" required></div></div><button class="btn btn-primary w-100 py-2" type="submit">Login <i class="bi bi-arrow-right ms-1"></i></button></form></section><?php if ($flash): ?><script>alert(<?= json_encode($flash['message']) ?>);</script><?php endif; ?></body></html>
