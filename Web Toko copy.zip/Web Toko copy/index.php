<?php
require_once __DIR__ . '/config/bootstrap.php';
if (is_logged_in()) {
	$user = current_user();
	if (!empty($user['role']) && $user['role'] === 'kasir') redirect('kasir/transaksi.php');
	if (!empty($user['role']) && $user['role'] === 'gudang') redirect('gudang/barang.php');
	redirect('dashboard.php');
}
redirect('login.php');
