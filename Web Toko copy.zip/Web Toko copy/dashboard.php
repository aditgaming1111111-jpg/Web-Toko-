<?php
require_once __DIR__ . '/config/bootstrap.php';
$user = require_login(['admin']);
$stats = [
 ['Total Barang', (int)$pdo->query('SELECT COUNT(*) FROM barang')->fetchColumn(), 'box-seam'],
 ['Total User', (int)$pdo->query('SELECT COUNT(*) FROM users')->fetchColumn(), 'people'],
 ['Penjualan Hari Ini', 'Rp ' . number_format((float)$pdo->query('SELECT COALESCE(SUM(total),0) FROM transaksi WHERE DATE(tanggal)=CURDATE()')->fetchColumn(),0,',','.'), 'cash-stack'],
 ['Total Transaksi', (int)$pdo->query('SELECT COUNT(*) FROM transaksi')->fetchColumn(), 'receipt'],
];
$lowStock = $pdo->query('SELECT kode_barang,nama_barang,stok,satuan FROM barang WHERE stok <= 10 ORDER BY stok ASC LIMIT 8')->fetchAll();
$recent = [];
if ($user['role'] === 'admin') {
    $recent = $pdo->query(
        'SELECT l.aktivitas, l.created_at, u.nama
         FROM log_aktivitas l
         LEFT JOIN users u ON u.id_user = l.id_user
         ORDER BY l.created_at DESC
         LIMIT 8'
    )->fetchAll();
}
$salesRows = $pdo->query(
    "SELECT DATE(tanggal) AS sale_date, COALESCE(SUM(total), 0) AS total
     FROM transaksi
     WHERE tanggal >= CURDATE() - INTERVAL 6 DAY
     GROUP BY DATE(tanggal)
     ORDER BY DATE(tanggal)"
)->fetchAll();

$salesByDate = [];
foreach ($salesRows as $sale) {
    $salesByDate[$sale['sale_date']] = (float) $sale['total'];
}

$salesLabels = [];
$salesValues = [];
for ($day = 6; $day >= 0; $day--) {
    $date = new DateTimeImmutable("-$day days");
    $salesLabels[] = $date->format('d M');
    $salesValues[] = $salesByDate[$date->format('Y-m-d')] ?? 0;
}
$pageTitle = 'Dashboard'; require __DIR__ . '/includes/header.php';
?>
<div class="d-flex align-items-center justify-content-between mb-4"><div><h1 class="section-title mb-1">Dashboard</h1><p class="text-muted mb-0">Ringkasan operasional toko hari ini.</p></div><span class="text-muted"><?= e(date('d F Y')) ?></span></div>
<div class="row g-3 mb-4"><?php foreach($stats as [$label,$value,$icon]): ?><div class="col-sm-6 col-xl-3"><div class="glass-card metric-card d-flex justify-content-between align-items-start"><div><div class="text-muted small mb-2"><?= e($label) ?></div><div class="metric-number"><?= e((string)$value) ?></div></div><div class="metric-icon"><i class="bi bi-<?= e($icon) ?>"></i></div></div></div><?php endforeach; ?></div>
<div class="row g-4"><div class="col-lg-8"><div class="card p-4 h-100"><h2 class="h5 mb-4">Grafik Penjualan 7 Hari Terakhir</h2><div class="chart-wrap"><canvas id="salesChart"></canvas></div></div></div><div class="col-lg-4"><div class="card p-4 h-100"><h2 class="h5 mb-3">Barang Hampir Habis</h2><?php if(!$lowStock): ?><p class="text-muted">Stok semua barang aman.</p><?php else: ?><div class="table-responsive"><table class="table table-sm align-middle"><tbody><?php foreach($lowStock as $item): ?><tr><td><strong><?= e($item['nama_barang']) ?></strong><small class="d-block text-muted"><?= e($item['kode_barang']) ?></small></td><td class="text-end"><span class="badge text-bg-warning"><?= e((string)$item['stok']) ?> <?= e($item['satuan']) ?></span></td></tr><?php endforeach; ?></tbody></table></div><?php endif; ?></div></div><?php if($user['role']==='admin'): ?><div class="col-12"><div class="card p-4"><h2 class="h5 mb-3">Aktivitas Terbaru</h2><div class="row g-3"><?php foreach($recent as $row): ?><div class="col-md-6 col-xl-3"><div class="border border-secondary-subtle rounded-3 p-3"><strong><?= e($row['aktivitas']) ?></strong><small class="d-block text-muted mt-1"><?= e($row['nama'] ?? 'Sistem') ?> · <?= e($row['created_at']) ?></small></div></div><?php endforeach; ?><?php if(!$recent): ?><p class="text-muted">Belum ada aktivitas.</p><?php endif; ?></div></div></div><?php endif; ?></div>
<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
  const chartCanvas = document.getElementById('salesChart');
  const chartContext = chartCanvas.getContext('2d');
  const salesGradient = chartContext.createLinearGradient(0, 0, 0, 300);
  salesGradient.addColorStop(0, 'rgba(139, 115, 255, .42)');
  salesGradient.addColorStop(1, 'rgba(139, 115, 255, 0)');

  new Chart(chartCanvas, {
    type: 'line',
    data: {
      labels: <?= json_encode($salesLabels) ?>,
      datasets: [{
        label: 'Penjualan (Rp)',
        data: <?= json_encode($salesValues) ?>,
        borderColor: '#a78bfa',
        backgroundColor: salesGradient,
        borderWidth: 3,
        fill: true,
        tension: .35,
        pointRadius: 4,
        pointHoverRadius: 6,
        pointBackgroundColor: '#ffffff',
        pointBorderColor: '#8b73ff'
      }]
    },
    options: {
      responsive: true,
      maintainAspectRatio: false,
      interaction: { intersect: false, mode: 'index' },
      plugins: {
        legend: { labels: { color: '#e9edf5' } },
        tooltip: {
          callbacks: {
            label: context => ' Rp ' + Number(context.raw).toLocaleString('id-ID')
          }
        }
      },
      scales: {
        x: { ticks: { color: '#9da5b4' }, grid: { color: 'rgba(255,255,255,.06)' } },
        y: {
          beginAtZero: true,
          ticks: {
            color: '#9da5b4',
            callback: value => 'Rp ' + Number(value).toLocaleString('id-ID')
          },
          grid: { color: 'rgba(255,255,255,.06)' }
        }
      }
    }
  });
</script>
<?php require __DIR__ . '/includes/footer.php'; ?>
