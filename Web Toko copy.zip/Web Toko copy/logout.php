<?php
declare(strict_types=1);

require_once __DIR__ . '/config/bootstrap.php';

$user = require_login();

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method tidak diizinkan.');
}

verify_csrf();
audit($pdo, (int) $user['id_user'], 'Logout dari sistem');
end_session('Anda telah berhasil logout.');
